package com.cg.dao;

import java.util.*;

import com.cg.dto.*;

/*NA*/
/**
 * 
 * This is a CarDAO class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */
public interface ProductDAO 
{
    public List<ProductDTO> findAll();
 
    public ProductDTO findById(int id);

    public void create(ProductDTO prod);

    public void update(ProductDTO prod);

    public void delete(String[] ids);

}