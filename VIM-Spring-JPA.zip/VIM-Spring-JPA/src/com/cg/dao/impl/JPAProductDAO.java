package com.cg.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.ProductDAO;

import com.cg.dto.ProductDTO;

@Repository
public class JPAProductDAO implements ProductDAO{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public void create(ProductDTO prod) {
		// TODO Auto-generated method stub
		
//		EntityTransaction tx = entityManager.getTransaction();
		try {
//			tx.begin();
			entityManager.persist(prod);
//			tx.commit();
			
			System.out.println("After commit .................");
			
		} catch (RuntimeException e) {
//			tx.rollback();
			throw e;
		} finally {
			entityManager.close();
		}
	}
	
	@Override
	public void delete(String[] ids) {
		
		EntityTransaction tx = entityManager.getTransaction();
		try {
			tx.begin();
			
			for(String sID : ids){
				ProductDTO prod = entityManager.find(ProductDTO.class, Integer.parseInt(sID));
				entityManager.remove(prod);
			}
			
			tx.commit();
		} catch (RuntimeException e) {
		tx.rollback();
		throw e;
		} finally {
		entityManager.close();
		}		
	}
	
	@Override
	public List<ProductDTO> findAll() {
		
		try {
			Query query = entityManager.createQuery(
			"select product from ProductDTO prod");
			return query.getResultList();
		} finally {
		entityManager.close();
		}
	}
	
	@Override
	public ProductDTO findById(int id) {
		
		ProductDTO prod = (ProductDTO) entityManager.find(ProductDTO.class, id);
		return prod;
	}
	
	@Override
	public void update(ProductDTO prod) {
		
		EntityTransaction tx = entityManager.getTransaction();
		try {
			tx.begin();
			entityManager.merge(prod);
			tx.commit();
			
			System.out.println("After commit .................");
			
		} catch (RuntimeException e) {
			tx.rollback();
			throw e;
		} finally {
			entityManager.close();
		}
	}
}
