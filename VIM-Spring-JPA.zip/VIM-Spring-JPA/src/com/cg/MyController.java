package com.cg;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;


import com.cg.dao.ProductDAO;
import com.cg.dto.ProductDTO;

@Controller
public class MyController {

	@Autowired
	private ProductDAO prodDAO;

	@RequestMapping("/viewProducts")
	String viewAllProducts(ModelMap map){
		List<ProductDTO> products = prodDAO.findAll();
		
		map.addAttribute("productList",products);
		System.out.println(products);
		return "productList";
	}
	
}
