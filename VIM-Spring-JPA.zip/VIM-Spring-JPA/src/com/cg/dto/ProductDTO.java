package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class ProductDTO
{
//	TODO:1 Oracle db is using strategy = GenerationType.SEQUENCE
//	TODO:2 MySQL db is using strategy = GenerationType.AUTO

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private int id;
	
	@Column(name = "NAME")
    private String name;
	
	@Column(name = "COST")
    private String cost;
	
	@Column(name = "CATEGORY")
    private String category;
	
	@Column(name = "DISCOUNT")
    private String discount;
	
	@Column(name = "DESCRIPTION")
    private String description;

    public ProductDTO()
    {
        this.id = -1;
        this.name = "";
        this.cost = "";
        this.category = "";   
        this.discount = ""; 
        this.description = ""; 
    }


}
